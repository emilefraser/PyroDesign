Eclipse 3.3.X instructions

---------- Required Google API Library for GWT variables ---------
Window->Preferences->General->Workspace->Linked Resources
Create a variable named "ajaxloader_API_ROOT" pointing to a working copy of the http://gwt-google-apis.googlecode.com/svn/trunk/ajaxloader folder.

Window->Preferences->Java->Build Path->Classpath Variables
Create a variable named "GWT_HOME" pointing to a GWT install folder.
Create a variable named "JDK_HOME" pointing to the root of your JDK install
  (for example, C:\Program Files\jdk1.5.0_05 or /usr/lib/j2sdk1.5-sun)

---------- All other settings ------------------------------------
All other eclipse settings can be found at:

http://google-web-toolkit.googlecode.com/svn/trunk/eclipse/README.txt
